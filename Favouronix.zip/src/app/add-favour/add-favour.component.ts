import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-favour',
  templateUrl: './add-favour.component.html',
  styleUrls: ['./add-favour.component.css']
})
export class AddFavourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
