export class LoginDetails 
{
    constructor(
        public email : string,
        public password : string
    ){}
}
