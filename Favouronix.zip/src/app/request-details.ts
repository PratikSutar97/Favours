export class RequestDetails 
{
    constructor(
        public title : string,
        public name : string,
        public desc : string,
        public reward : string
    ){}
}
