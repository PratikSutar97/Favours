import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-return-favour',
  templateUrl: './return-favour.component.html',
  styleUrls: ['./return-favour.component.css']
})
export class ReturnFavourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
