import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-favours',
  templateUrl: './member-favours.component.html',
  styleUrls: ['./member-favours.component.css']
})
export class MemberFavoursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
